// Data storage
let data = {
    customers: [],
    branches: [],
    users: []
};

// Constants
const ITEMS_PER_PAGE = 15;
let currentPage = 1;

// Initialize data with some sample entries
function initializeData() {
    // Generate sample data for each category
    for (let i = 1; i <= 30; i++) {
        data.customers.push({ id: i, name: `Customer ${i}` });
        data.branches.push({ id: i, name: `Branch ${i}` });
        data.users.push({ id: i, name: `User ${i}` });
    }
}

// Theme switcher
document.getElementById('themeSwitcher').addEventListener('click', function() {
    const body = document.body;
    const icon = this.querySelector('i');
    if (body.getAttribute('data-bs-theme') === 'dark') {
        body.setAttribute('data-bs-theme', 'light');
        icon.classList.remove('bi-moon');
        icon.classList.add('bi-sun');
    } else {
        body.setAttribute('data-bs-theme', 'dark');
        icon.classList.remove('bi-sun');
        icon.classList.add('bi-moon');
    }
});

// Search functionality
document.getElementById('searchInput')?.addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const currentPage = window.location.pathname.split('/').pop();
    
    let filteredData;
    if (currentPage === 'index.html' || currentPage === '') {
        filteredData = data.customers.filter(item => 
            item.name.toLowerCase().includes(searchTerm)
        );
        displayCustomers(filteredData);
    } else if (currentPage === 'branch.html') {
        filteredData = data.branches.filter(item => 
            item.name.toLowerCase().includes(searchTerm)
        );
        displayBranches(filteredData);
    } else if (currentPage === 'users.html') {
        filteredData = data.users.filter(item => 
            item.name.toLowerCase().includes(searchTerm)
        );
        displayUsers(filteredData);
    }
});

// Pagination
function createPagination(totalItems, currentPage, itemsPerPage) {
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const paginationElement = document.getElementById('pagination');
    paginationElement.innerHTML = '';

    for (let i = 1; i <= totalPages; i++) {
        const li = document.createElement('li');
        li.className = `page-item ${currentPage === i ? 'active' : ''}`;
        li.innerHTML = `<a class="page-link" href="#" onclick="changePage(${i})">${i}</a>`;
        paginationElement.appendChild(li);
    }
}

function changePage(page) {
    currentPage = page;
    const currentPath = window.location.pathname.split('/').pop();
    
    if (currentPath === 'index.html' || currentPath === '') {
        displayCustomers(data.customers);
    } else if (currentPath === 'branch.html') {
        displayBranches(data.branches);
    } else if (currentPath === 'users.html') {
        displayUsers(data.users);
    }
}

// Display functions
function displayCustomers(customers = data.customers) {
    const tableBody = document.getElementById('customerTableBody');
    if (!tableBody) return;

    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    const paginatedItems = customers.slice(start, start + ITEMS_PER_PAGE);
    
    tableBody.innerHTML = paginatedItems.map(customer => `
        <tr>
            <td>${customer.id}</td>
            <td>${customer.name}</td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-gear"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#" onclick="editCustomer(${customer.id})">Edit</a></li>
                        <li><a class="dropdown-item" href="#" onclick="deleteCustomer(${customer.id})">Delete</a></li>
                    </ul>
                </div>
            </td>
        </tr>
    `).join('');

    createPagination(customers.length, currentPage, ITEMS_PER_PAGE);
}

function displayBranches(branches = data.branches) {
    const tableBody = document.getElementById('branchTableBody');
    if (!tableBody) return;

    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    const paginatedItems = branches.slice(start, start + ITEMS_PER_PAGE);
    
    tableBody.innerHTML = paginatedItems.map(branch => `
        <tr>
            <td>${branch.id}</td>
            <td>${branch.name}</td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-gear"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#" onclick="editBranch(${branch.id})">Edit</a></li>
                        <li><a class="dropdown-item" href="#" onclick="deleteBranch(${branch.id})">Delete</a></li>
                    </ul>
                </div>
            </td>
        </tr>
    `).join('');

    createPagination(branches.length, currentPage, ITEMS_PER_PAGE);
}

function displayUsers(users = data.users) {
    const tableBody = document.getElementById('userTableBody');
    if (!tableBody) return;

    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    const paginatedItems = users.slice(start, start + ITEMS_PER_PAGE);
    
    tableBody.innerHTML = paginatedItems.map(user => `
        <tr>
            <td>${user.id}</td>
            <td>${user.name}</td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-gear"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#" onclick="editUser(${user.id})">Edit</a></li>
                        <li><a class="dropdown-item" href="#" onclick="deleteUser(${user.id})">Delete</a></li>
                    </ul>
                </div>
            </td>
        </tr>
    `).join('');

    createPagination(users.length, currentPage, ITEMS_PER_PAGE);
}

// CRUD Operations for Customers
function addCustomer() {
    const name = document.getElementById('customerName').value;
    const newId = data.customers.length > 0 ? Math.max(...data.customers.map(c => c.id)) + 1 : 1;
    data.customers.push({ id: newId, name });
    bootstrap.Modal.getInstance(document.getElementById('addModal')).hide();
    displayCustomers();
}

function editCustomer(id) {
    const customer = data.customers.find(c => c.id === id);
    document.getElementById('editId').value = customer.id;
    document.getElementById('editName').value = customer.name;
    new bootstrap.Modal(document.getElementById('editModal')).show();
}

function updateCustomer() {
    const id = parseInt(document.getElementById('editId').value);
    const name = document.getElementById('editName').value;
    const index = data.customers.findIndex(c => c.id === id);
    data.customers[index].name = name;
    bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
    displayCustomers();
}

function deleteCustomer(id) {
    if (confirm('Are you sure you want to delete this customer?')) {
        data.customers = data.customers.filter(c => c.id !== id);
        displayCustomers();
    }
}

// CRUD Operations for Branches
function addBranch() {
    const name = document.getElementById('branchName').value;
    const newId = data.branches.length > 0 ? Math.max(...data.branches.map(b => b.id)) + 1 : 1;
    data.branches.push({ id: newId, name });
    bootstrap.Modal.getInstance(document.getElementById('addModal')).hide();
    displayBranches();
}

function editBranch(id) {
    const branch = data.branches.find(b => b.id === id);
    document.getElementById('editId').value = branch.id;
    document.getElementById('editName').value = branch.name;
    new bootstrap.Modal(document.getElementById('editModal')).show();
}

function updateBranch() {
    const id = parseInt(document.getElementById('editId').value);
    const name = document.getElementById('editName').value;
    const index = data.branches.findIndex(b => b.id === id);
    data.branches[index].name = name;
    bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
    displayBranches();
}

function deleteBranch(id) {
    if (confirm('Are you sure you want to delete this branch?')) {
        data.branches = data.branches.filter(b => b.id !== id);
        displayBranches();
    }
}

// CRUD Operations for Users
function addUser() {
    const name = document.getElementById('userName').value;
    const newId = data.users.length > 0 ? Math.max(...data.users.map(u => u.id)) + 1 : 1;
    data.users.push({ id: newId, name });
    bootstrap.Modal.getInstance(document.getElementById('addModal')).hide();
    displayUsers();
}

function editUser(id) {
    const user = data.users.find(u => u.id === id);
    document.getElementById('editId').value = user.id;
    document.getElementById('editName').value = user.name;
    new bootstrap.Modal(document.getElementById('editModal')).show();
}

function updateUser() {
    const id = parseInt(document.getElementById('editId').value);
    const name = document.getElementById('editName').value;
    const index = data.users.findIndex(u => u.id === id);
    data.users[index].name = name;
    bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
    displayUsers();
}

function deleteUser(id) {
    if (confirm('Are you sure you want to delete this user?')) {
        data.users = data.users.filter(u => u.id !== id);
        displayUsers();
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeData();
    
    // Display initial data based on current page
    const currentPath = window.location.pathname.split('/').pop();
    if (currentPath === 'index.html' || currentPath === '') {
        displayCustomers();
    } else if (currentPath === 'branch.html') {
        displayBranches();
    } else if (currentPath === 'users.html') {
        displayUsers();
    }
});